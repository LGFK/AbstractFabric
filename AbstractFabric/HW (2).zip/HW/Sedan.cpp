#include "Sedan.h"

Sedan::Sedan(const string& n,int wheels):Car(n,wheels)
{

}


