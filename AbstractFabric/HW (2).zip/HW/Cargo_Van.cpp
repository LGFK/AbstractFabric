#include "Cargo_Van.h"

Cargo_Van::Cargo_Van(const string& n,int wheels):Car(n,wheels)
{
}

