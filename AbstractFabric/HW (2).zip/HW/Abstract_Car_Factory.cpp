#include "Abstract_Car_Factory.h"

Abstract_Car_Factory::Abstract_Car_Factory() = default;

Abstract_Car_Factory::~Abstract_Car_Factory() = default;


