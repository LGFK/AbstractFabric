#include "Bus.h"

Bus::Bus(const string& n,int wheels) :Car(n,wheels)
{

}


